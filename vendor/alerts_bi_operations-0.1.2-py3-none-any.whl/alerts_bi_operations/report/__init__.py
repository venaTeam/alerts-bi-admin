"""Alerts BI report package."""
