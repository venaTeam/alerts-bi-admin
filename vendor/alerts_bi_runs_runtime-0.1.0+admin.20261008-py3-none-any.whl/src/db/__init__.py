"""Historical migration import compatibility."""
