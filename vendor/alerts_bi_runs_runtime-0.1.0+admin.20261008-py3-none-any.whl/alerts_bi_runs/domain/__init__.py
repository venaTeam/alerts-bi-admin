"""Alerts BI domain package."""
