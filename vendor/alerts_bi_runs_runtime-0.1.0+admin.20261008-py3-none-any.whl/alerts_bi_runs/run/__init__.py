"""Alerts BI run package."""
