"""Alerts BI rules package."""
