"""Alerts BI db package."""
